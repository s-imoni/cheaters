#include <stdlib.h>
#include <stdio.h>
#include "string.h"

void populateWorld(char fname[], char *grid[], int *numRows, int *numCols);

void floodFill(char *grid[], int numRows, int numCols, int row, int col, char color, char initialLoc);

void showWorld(char *grid[], int numRows, int numCols);

int main(int argc, char *argv[]){
    char file[80];
    strcpy(file, argv[1]);
    const int MAX_ROWS = 25;
    char *world[MAX_ROWS];
    int numRows;
    int numCols;
    populateWorld(file, world, &numRows, &numCols);
    showWorld(world, numRows, numCols);

    int col = 0;
    int row = 0;
    char color;
    while(row != -1 && col != -1) {
        printf("\nEnter a row:");
        scanf("%d", &row);
        printf("Enter a column:");
        scanf("%d", &col);
        printf("Enter a color:");
        scanf(" %c", &color);
        if(row >= numRows || row < -1 || col >= numCols || col < -1){
            printf("Row or column out of bounds\n");
            exit(-1);
        }
        if(row != -1 && col != -1) {
	    if(color != world[row][col]){
		 char init = world[row][col];
           	 floodFill(world, numRows, numCols, row, col, color, init);
            }
            printf("\n");
            showWorld(world, numRows, numCols);
        }
    }

    for(int i = 0; i < numRows; i++){
        free(world[i]);
    }

    return 0;
}

/*
 * Takes a string that consists of a file name (fname) and stores the values
 * from the file in a 2D character array (grid). Also calculates number of
 * rows (numRows) and columns (numCols) in grid.
 *
 * Preconditions: fname[] will have a should length of 80
 * Postconditions: grid will store the contents of fname[]
 */
void populateWorld(char fname[], char *grid[], int *numRows, int *numCols) {
    *numRows = 0;
    *numCols = 0;
    const int MAX_LEN = 80;
    char currentRow[MAX_LEN];
    FILE *inputFile = fopen(fname, "r");

    // Exit on error
    if(inputFile == NULL){
        printf("Error in Opening File");
        exit(-1);
    }
    // Read each row and store in grid
    while (fgets(currentRow, MAX_LEN, inputFile) != NULL) {
        // Calculate numCols, exclude '\n'
        if(*numRows == 0) {
            *numCols = strlen(currentRow) - 1;
	    if(strlen(currentRow) == 1){
            	*numCols = *numCols + 1;
            }
        }
        //Replace '\n' with NULL at the end of string
        currentRow[*numCols] = '\0';
        grid[*numRows] = malloc((*numCols) * sizeof(char));
        strncpy(grid[*numRows], currentRow, *numCols);
        // Increment row to calculate row
        *numRows = *numRows + 1;
    }
    fclose(inputFile);
}

/*
 * Takes a 2D character array and replaces all neighboring pixels with the same
 * color as the pixel location provided in startLoc and replaces it with the color
 * provided in startLoc
 *
 * Preconditions: row, col, color for location to replace. grid[] is filled and no greater than 25x25
 * Postconditions: grid[] has been floodFilled by the color in startLoc
 */
void floodFill(char *grid[], int numRows, int numCols, int row, int col, char color, char initialLoc){
   if(row >= 0 && row < numRows && col >=0 && col < numRows && grid[row][col] == initialLoc){ 
      grid[row][col] = color;
      floodFill(grid, numRows, numCols, row + 1, col, color, initialLoc);
      floodFill(grid, numRows, numCols, row - 1, col, color, initialLoc);
      floodFill(grid, numRows, numCols, row, col + 1, color, initialLoc);
      floodFill(grid, numRows, numCols, row, col - 1, color, initialLoc);
      floodFill(grid, numRows, numCols, row + 1, col + 1, color, initialLoc);
      floodFill(grid, numRows, numCols, row - 1, col + 1, color, initialLoc);
      floodFill(grid, numRows, numCols, row - 1, col - 1, color, initialLoc);
      floodFill(grid, numRows, numCols, row + 1, col - 1, color, initialLoc);
   }   
}

/*
 * Takes a 2D character array (grid), and the number of rows (numRows) and
 * columns (numCols) and outputs it the the screen.
 *
 * Preconditions: 2D character array (grid)
 * Postconditions: 2D array output to console
 */
void showWorld(char *grid[], int numRows, int numCols){
    for(int row = 0; row < numRows; row++){
        for(int col = 0; col < numCols; col++) {
            printf("%c", grid[row][col]);
        }
        printf("\n");
    }
}
