1) Unzip Files
2) Type make and hit enter
3) Type ./flood "filename.txt" and hit enter in order to run

** remember to replace filename.txt with the file you'd like to use