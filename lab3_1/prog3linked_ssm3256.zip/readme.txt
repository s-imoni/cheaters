1) Unzip
2) Run the following commands, but replace filename with intended file:
	make
	./flood "filename.txt"
