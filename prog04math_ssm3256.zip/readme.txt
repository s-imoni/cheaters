Unzip Files
Navigate to Director
Type make and hit enter
Type ./rec and hit enter
