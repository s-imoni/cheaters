Unzip.
Type make and hit enter to compile
Type ./equation "file_name.txt" and hit enter to compile. Replace file name with intended file.
