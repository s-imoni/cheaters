/* Student information for project:
 *
 * On my honor, Simoni Maniar, this programming project is my own work
 * and I have not provided this code to any other student.
 *
 * Name: Simoni Maniar
 * email address: s.imoni@utexas.edu
 * UTEID: ssm3256
 * Section 5 digit ID: 16115
 *
 */

#ifndef UNTITLED1_LIFE_H
#define UNTITLED1_LIFE_H

#endif //UNTITLED1_LIFE_H

void populateWorld(char fname[], char *grid[], int *numRows, int *numCols);

void showWorld(char *grid[], int numRows, int numCols);

void iterateGeneration(char *grid[], int numRows, int numCols);
